#include <stdio.h> 

void tampilkan_judul();
double hitung_luas (double jari_jari); 
double hitung_keliling (double jari_jari); 
void tampilkan_hasil (
    double jari_jari,
    double luas,
    double keliling
);
  
int main(void) 
{ 
    double jari_jari; 
    double luas; 
    double keliling; 
  
    printf("Masukkan jari-jari: "); 
    scanf("%lf", &jari_jari); 

    if (jari_jari < 0.0)
    {
        printf("Jari jari wajib melebihi nol");
        return 1;
    }
  
    luas = hitung_luas(jari_jari); 
    keliling = hitung_keliling(jari_jari); 

    tampilkan_hasil (jari_jari, luas, keliling);

    return 0; 
} 

void tampilkan_judul()
{
    printf("\n+========================================+\n");
    printf("\n+           MENGHITUNG LINGKARAN         +\n");
    printf("\n+========================================+\n");
}
  
double hitung_luas(double jari_jari) 
{ 
    const double PHI = 3.141592653589793; 
  
    return PHI * jari_jari * jari_jari; 
} 
  
double hitung_keliling(double jari_jari) 
{ 
    const double PHI = 3.141592653589793; 
  
    return PHI * 2.0 * jari_jari; 
}

void tampilkan_hasil
(
    double jari_jari,
    double luas,
    double keliling
)
{
    printf("\nREKAP HASIL PERHITUNGAN LINGKARAN\n");
    printf("Jari-jari  : %.2f\n", jari_jari);
    printf("Luas       : %.2f\n", luas);
    printf("Keliling   : %.2f\n", keliling);
}
