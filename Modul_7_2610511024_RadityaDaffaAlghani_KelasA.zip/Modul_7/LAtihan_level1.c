#include <stdio.h>

void tampilkan_judul();
int hitung_kuadrat(int bilangan);
int hitung_kubik(int bilangan);
void tampilkan_hasil 
(
    int bilangan,
    int kuadrat,
    int kubik
);

int main()
{
    int bilangan, kuadrat, kubik;

    printf("Masukkan Bilangan : ");
    scanf("%d", &bilangan);

    kuadrat = hitung_kuadrat (bilangan);
    kubik = hitung_kubik (bilangan);

    tampilkan_hasil (bilangan, kuadrat, kubik);

    return 0;
}

void tampilkan_judul()
{
    printf("=================================\n");
    printf("     HITUNG ANGKA MATEMATIS\n");
    printf("=================================\n");
}

int hitung_kuadrat(int bilangan)
{
    return bilangan * bilangan;
}

int hitung_kubik (int bilangan)
{
    return bilangan * bilangan * bilangan;
}

void tampilkan_hasil
(
    int bilangan,
    int kuadrat,
    int kubik
)
{
    printf("\nHASIL PERHITUNGAN\n");
    printf("Bilangan : %d\n", bilangan);
    printf("Kuadrat  : %d\n", kuadrat);
    printf("Kubik    : %d\n", kubik);
}