#include <stdio.h>

void tampilkan_judul();
int jumlah_digit (int n);
void tampilkan_hasil 
(
    int n
    
);

int main()
{
    int angka;

    printf("Masukkan Bilangan : ");
    scanf("%d", &angka);

    if (angka < 0)
    {
        printf("Angka yang ingin dihitung tidak valid.\n");
        return 1;
    }

    printf("Jumlah digit : %d\n", jumlah_digit);

    return 0;
}

int jumlah_digit(int n)
{
    if (n < 10)
    {
        return n;
    }
    return (n % 10) + jumlah_digit (n / 10); 
}