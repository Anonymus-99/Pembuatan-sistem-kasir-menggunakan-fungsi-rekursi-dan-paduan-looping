#include <stdio.h>

int apakah_genap(int bilangan);

int main(void)
{
    int i;
    int bilangan;
    int jumlah_genap = 0;
    int jumlah_ganjil = 0;
    int jumlah_angka = 10;

    for (i = 1; i <= jumlah_angka; i++)
    {
        printf("Masukkan bilangan ke-%d: ", i);
        scanf("%d", &bilangan);

        if (apakah_genap(bilangan))
        {
            jumlah_genap++;
        }
        else
        {
            jumlah_ganjil++;
        }
    }

    printf("Jumlah bilangan genap : %d\n", jumlah_genap);
    printf("Jumlah bilangan ganjil: %d\n", jumlah_ganjil);

    return 0;
}

int apakah_genap(int bilangan)
{
    if (bilangan % 2 == 0)
    {
        return 1;
    }
    return 0;
}