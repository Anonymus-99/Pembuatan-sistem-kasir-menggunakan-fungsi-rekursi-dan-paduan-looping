#include <stdio.h>
void tampilkan_judul();
int hitung_jam(int total_detik);
int hitung_sisa_setelah_jam(int total_detik);
int hitung_menit(int sisa_detik);
int hitung_detik(int sisa_detik);
void tampilkan_waktu 
(
    int total_detik,
    int jam,
    int menit,
    int sisa_detik, 
    int detik
);

int main()
{
    int total_detik, jam, menit, sisa_detik, detik;

    tampilkan_judul ();
    
    printf("Masukkan total detik : ");
    scanf("%d", &total_detik);

    if (total_detik < 0)
    {
        printf("Total detik tidak boleh negatif.\n");
        return 1;
    }

    jam = hitung_jam (total_detik);
    sisa_detik = hitung_sisa_setelah_jam(total_detik);
    menit = hitung_menit(sisa_detik);
    detik = hitung_detik(sisa_detik);

    tampilkan_waktu (total_detik, jam, menit, sisa_detik, detik);

    return 0;
}

void tampilkan_judul ()
{
    printf("==============================\n");
    printf("          ALUR WAKTU\n");
    printf("==============================\n");
}

int hitung_jam (int total_detik)
{
    return total_detik / 3600;
}

int hitung_sisa_setelah_jam (int total_detik)
{
    return total_detik % 3600;
}

int hitung_menit (int sisa_detik)
{
    return sisa_detik / 60;
}

int hitung_detik (int sisa_detik)
{
    return sisa_detik % 60;
}

void tampilkan_waktu 
(
    int total_detik,
    int jam,
    int menit,
    int sisa_detik,
    int detik 
)
{
    printf("\nHASIL REKAP MENGHITUNG WAKTU\n");
    printf("%d detik setara dengan : \n", total_detik);
    printf("%d jam\n", jam);
    printf("%d menit\n", menit);
    printf("%d detik\n", detik);
}