#include <stdio.h>

int apakah_prima(int bilangan);

int main(void)
{
    int batas;
    int i;

    printf("Masukkan batas: ");
    scanf("%d", &batas);

    printf("Bilangan prima dari 1 sampai %d:\n", batas);
    for (i = 1; i <= batas; i++)
    {
        if (apakah_prima(i))
        {
            printf("%d ", i);
        }
    }
    printf("\n");

    return 0;
}

int apakah_prima(int bilangan)
{
    int pembagi;

    if (bilangan < 2)
    {
        return 0;
    }

    for (pembagi = 2; pembagi * pembagi <= bilangan; pembagi++)
    {
        if (bilangan % pembagi == 0)
        {
            return 0;
        }
    }
    return 1;
}