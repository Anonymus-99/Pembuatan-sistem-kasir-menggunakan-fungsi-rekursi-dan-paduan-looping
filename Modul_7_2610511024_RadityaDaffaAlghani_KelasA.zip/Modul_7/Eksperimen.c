#include <stdio.h>

int main()
{
    int x = 5;
    int y = 15;
    int hasil;

    printf("Dalam Modul tidak terdapat eksperimen, yang ada hanya tracing saja.\nTerima kasih :)\n");

    hasil = x + y;

    printf("Hasil : %d\n", hasil);

    return 0;
}