#include <stdio.h>

double tambah(double a, double b);
double kurang(double a, double b);
double kali(double a, double b);
double bagi(double a, double b);
void tampilkan_menu(void);

enum KalkulatorMatematika 
{
    Penjumlahan,
    Pengurangan,
    Perkalian,
    Pembagian
};

int main()
{
    double a, b;

    printf("Nilai a adalah : ");
    scanf("%lf", &a);

    printf("Nilai b adalah : ");
    scanf("%lf", &b);

    if((a < 0.0)||(b < 0.0))
    {
        printf("Nilai tidak valid.\n");
    }
    
    enum KalkulatorMatematika jenis = Pembagian;
        switch(jenis)
        {
            case Penjumlahan :
              printf("Hasil : %.2f\n", tambah(a,b));
              break;

            case Pengurangan : 
              printf("Hasil : %.2f\n", kurang(a,b));
              break;

            case Perkalian :
              printf("Hasil : %.2f\n", kali(a,b));
              break;

            case Pembagian :
              printf("Hasil : %.2f\n", bagi(a,b));
              break;

            default :
            printf("Case tidak valid.\n");
            break;
        }
        return 0;
    }
    void tampilkan_menu()
    {
        printf("=============================\n");
        printf("     KALKULATOR MATEMATIKA\n");
        printf("=============================\n");
        printf("Penjumlahan.\n");
        printf("Pengurangan.\n");
        printf("Perkalian.\n");
        printf("Pembagian.\n");
    }

    double tambah(double a, double b)
    {
        return a + b;
    }

    double kurang(double a, double b)
    {
        return a - b;
    }

    double kali(double a, double b)
    {
        return a * b;
    }

    double bagi(double a, double b)
    {
        return a / b;
    }